sap.ui.define([],function(){"use strict";return{formatField:function(e,r,t){if(e||r){return true}else if(t){return false}return false}}});
//# sourceMappingURL=formatter.js.map