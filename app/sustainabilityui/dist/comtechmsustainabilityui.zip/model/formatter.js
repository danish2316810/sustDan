sap.ui.define([],function(){"use strict";return{formatField:function(e,r,t){if(e){return true}else if(r){return true}else if(t){return false}return false}}});
//# sourceMappingURL=formatter.js.map